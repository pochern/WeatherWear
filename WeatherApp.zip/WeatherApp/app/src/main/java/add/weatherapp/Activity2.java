package add.weatherapp;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View.OnKeyListener;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.ServerError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.JsonHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import cz.msebera.android.httpclient.Header;
import xyz.matteobattilana.library.Common.Constants;

public class Activity2 extends AppCompatActivity implements OnKeyListener {

    private EditText searchBarC;
    public final static String MESSAGE_KEY =  "STC";
    private TextView noresults;
    private Bundle bundle = new Bundle();

    ImageButton closeButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);

        searchBarC = (EditText)findViewById(R.id.searchCity);
        searchBarC.setOnKeyListener(this);

        noresults = (TextView)findViewById(R.id.noResults);

        closeButton = (ImageButton)findViewById(R.id.close);
        closeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivity1(v);
            }
        });

    }

    @Override
    public boolean onKey(View v, int keyCode, KeyEvent event) {
        String site = null;
        if (v == searchBarC) {
            //If the keyevent is a key-down event on the "enter" button
            if ((event.getAction() == android.view.KeyEvent.ACTION_DOWN) && (keyCode == android.view.KeyEvent.KEYCODE_ENTER)) {
                String searchString = searchBarC.getText().toString();
                searchCity(searchString);
                return true;
            }

        }
        return false;
    }

    public void openActivity1(View view){
        closeButton.setColorFilter(Color.argb(255, 0, 0, 0)); // Black Tint
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        Intent openMainActivity= new Intent(this, MainActivity.class);
        openMainActivity.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        startActivityIfNeeded(openMainActivity, 0);

    }

//    public void openActivity1Data(View view, Bundle searchString){
//        Intent intent = new Intent(this, MainActivity.class);
//        intent.putExtra(MESSAGE_KEY, searchString);
//        startActivity(intent);
//        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
//    }

    public void searchCity(String searchString){
        String url = "https://api.openweathermap.org/data/2.5/weather?q="+searchString+"&appid=41d9937fdb964001115c1cb63632e137&units=Imperial";
        JsonObjectRequest jor = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>(){
            @Override
            public void onResponse(JSONObject response){
                try{
                    Log.d("mytag", "This is a response");
                    JSONObject main_object = response.getJSONObject("main");
                    JSONArray array = response.getJSONArray("weather");
                    JSONObject object = array.getJSONObject(0);
                    String temp = String.valueOf(main_object.getDouble("temp"));
                    bundle.putString("tempy", temp);
                    String description = object.getString("description");
                    bundle.putString("descy", description);
                    String icon = object.getString("icon");
                    bundle.putString("icony", icon);
                    String city = response.getString("name");
                    bundle.putString("cityy", city);

                    noresults.setText("");

                    Intent intent = new Intent(Activity2.this, MainActivity.class);
                    intent.putExtra("lol", bundle);
                    startActivity(intent);
                    overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);


                }catch (JSONException e){
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error){
                NetworkResponse response = error.networkResponse;
                if (error instanceof ServerError && response != null) {
                    noresults.setText("NO RESULTS");

                }
            }
        }
        );

        RequestQueue queue = Volley.newRequestQueue(this);
        queue.add(jor);
    }

}
